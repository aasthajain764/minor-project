<!DOCTYPE html>
<head><title>Message</title></head>
<body style="background-color:#013d47; color:#fff; text-align:center; vertical-align:center;">
<br><br><br><br><br><br><br><br><br><br><br><br><br>
<h1>Your message has been sent!</h1>
</body>